import React from "react";
import { NavLink } from "react-router-dom";
import cir from "./images/chrome-icon-7.png";
import cirr from "./images/chrome-icon-6.png";

export default function Nav() {
  return (
    <nav className="teal heading">
      <div className="nav-wrapper container">
        <a href="/" className="brand-logo">
          <img src={cir} alt="" />
          <img src={cirr} alt="" />
        </a>
        <ul className="right hide-on-med-and-down tabss">
          <li className="tab" id="tab1">
            <NavLink to="/" className="funt" activeClassName="active">
              Search
            </NavLink>
          </li>
          <li className="tab tab2" id="tab2">
            <NavLink to="/readList" className="funt" activeClassName="active">
              My Reading List
            </NavLink>
          </li>
          <li>
            <a
              href="https://developers.google.com/books/docs/v1/reference/volumes"
              className="funt"
            >
              About the API
            </a>
          </li>
        </ul>
      </div>
    </nav>
  );
}
