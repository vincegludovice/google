import React from "react";
import list from "./images/reading-list-1024x512.jpg";

export default class ReadList extends React.Component {
  render() {
    return (
      <div className="col s12">
        <div className="row">
          <div className="col s6 offset-s3">
            <div className="card">
              <div className="card-image  img-cust">
                <img className="img-c" src={list} alt="" />
              </div>
            </div>
          </div>
          <article className="container">
            <div className="row">
              <div className="preloader-background pre2">
                <div className="load load2">
                  <hr />
                  <hr />
                  <hr />
                  <hr />
                </div>
              </div>
              <div id="printHere2"></div>
            </div>
          </article>
        </div>
      </div>
    );
  }
}
