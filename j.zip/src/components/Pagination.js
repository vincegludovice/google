import React from "react";

export default class Query extends React.Component {
  render() {
    return (
      <div className="row">
        <div className="col s6 offset-s3">
          <ul className="pagination" id="pagination"></ul>
        </div>
      </div>
    );
  }
}
