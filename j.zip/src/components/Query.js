import React from "react";
import axios from "axios";

const key = "AIzaSyCXCu8PHC8PGPA2aL-6xG3brBe5jEqukvg";

export default class Query extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      students: {}
    };
  }
  componentDidMount() {
    // console.log()
    // axios
    //   .get(
    //     `https://www.googleapis.com/books/v1/volumes?q=${this.props.match.params.term}&key=${key}`
    //   )
    //   .then(response => {
    //     this.setState({
    //       students: response.data
    //     });
    //   });
  }
  details = isbn => {
    this.props.isbns(isbn);
  };
  render() {
    return this.state.students.items
      ? this.state.students.items
          .map(books => books.volumeInfo)
          .map(booki => {
            var img = booki.imageLinks ? booki.imageLinks.thumbnail : "",
              title = booki.title,
              aut = booki.authors ? booki.authors[0] : "",
              desc = booki.description,
              year = booki.publishedDate
                ? booki.publishedDate.substring(0, 4)
                : "",
              isbn = booki.industryIdentifiers
                ? booki.industryIdentifiers[0].identifier
                : "";
            return (
              <div key={isbn} className="col m6 s12 hov1">
                <div className="card medium custom">
                  <div className="card-content white-text">
                    <div className="book">
                      <div className="img hov2">
                        <img src={img} alt="Image not available" />
                      </div>
                      <div className="info hov3">
                        <h3>{title ? title : "Title not available"}</h3>
                        <h6>
                          by {aut ? aut : "Author not available"}
                          {year ? " • " + year : ""}
                        </h6>
                        <p id="imp">
                          {desc ? desc : "Book Description not available"}
                        </p>
                        <div>
                          <button
                            className="btn waves-effect waves-light right-align yellow black-text"
                            id="readList"
                          >
                            Add to My Reading List
                          </button>
                          <button
                            className="btn waves-effect waves-light right-align modal-trigger blue"
                            data-target="modal2"
                            id="preview"
                          >
                            Preview
                          </button>
                          <button
                            className="btn waves-effect waves-light right-align modal-trigger"
                            onClick={() => this.details(isbn)}
                            data-target="modal1"
                            // id="details"
                          >
                            Details
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
      : null;
  }
}
