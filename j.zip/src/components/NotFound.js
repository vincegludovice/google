import React from "react";

//const Notfound = () => <h1>Not found</h1>;
export default class Notfound extends React.Component {
  render() {
    const { params } = this.props.match;
    return (
      <div>
        <h1>Users</h1>
        <p>{params.term}</p>
      </div>
    );
  }
}
