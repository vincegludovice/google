import React, { Component } from "react";
import M from "materialize-css";
import axios from "axios";
// import "./css/materialize-css/dist/css/materialize.min.css";
const key = "AIzaSyCXCu8PHC8PGPA2aL-6xG3brBe5jEqukvg";
const ISO6391 = require("iso-639-1");

class Modal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isbn: this.props.isbn,
      students: {}
    };
  }
  componentDidMount() {
    console.log(this.state.isbn);
    M.Modal.init(this.Modal);
    // let instance = M.Modal.getInstance(this.Modal);
    // instance.open();
    // instance.close();
    // instance.destroy();
    // axios
    //   .get(
    //     `https://www.googleapis.com/books/v1/volumes?q=isbn:${this.props.isbn}&key=${key}`
    //   )
    //   .then(response => {
    //     this.setState({
    //       students: response.data
    //     });
    //   });
  }
  render() {
    return null;
    // return this.state.students.items
    //   ? this.state.students.items
    //       .map(deta => deta.volumeInfo)
    //       .map(detai => {
    //         var imge = detai.imageLinks
    //             ? detai.imageLinks.thumbnail.replace("zoom=1", "zoom=0")
    //             : "",
    //           title = detai.title,
    //           aut = detai.authors
    //             ? detai.authors.map(aut => <li>&nbsp;&nbsp;{aut} </li>).join("")
    //             : "",
    //           rat = detai.averageRating,
    //           totalRat = detai.ratingsCount,
    //           lang = ISO6391.getName(detai.language),
    //           pages = detai.pageCount ? ", " + detai.pageCount + " pages" : "",
    //           desc = detai.description ? detai.description : "",
    //           year = detai.publishedDate.substring(0, 4),
    //           date = new Date(detai.publishedDate),
    //           options = { year: "numeric", month: "long", day: "numeric" },
    //           pub = detai.publisher;
    //         return (
    //           <div>
    //             <div className="col s4" id="her">
    //               <img
    //                 id="imahe"
    //                 src={imge ? imge : ""}
    //                 alt="Image not available"
    //               />
    //             </div>
    //             <div className="col s8 info2">
    //               <a className="modal-close btn-floating btn-large waves-effect waves-light red close">
    //                 <i className="material-icons">close</i>
    //               </a>
    //               <h3>{title ? title : "Title not available"}</h3>
    //               <h6>
    //                 by <ul id="autho">{aut}</ul>
    //                 {year ? " • " + year : ""}
    //               </h6>
    //               <h5>
    //                 {rat ? "Average Rating: " + rat + " • " : ""}
    //                 {totalRat ? totalRat + " ratings" : ""}{" "}
    //               </h5>
    //               <h5>
    //                 {lang} {pages}
    //               </h5>
    //               <h5>
    //                 {"Published " + date.toLocaleDateString("en-US", options)}{" "}
    //                 {"by"} {pub}
    //               </h5>
    //               <div>
    //                 <p>{desc}</p>
    //               </div>
    //             </div>
    //           </div>
    //         );
    //       })
    //   : null;
    // <div>
    //   <div
    //     ref={Modal => {
    //       this.Modal = Modal;
    //     }}
    //     id="modal1"
    //     className="modal"
    //   >
    //     {/* If you want Bottom Sheet Modal then add
    //                   bottom-sheet class to the "modal" div
    //                   If you want Fixed Footer Modal then add
    //                   modal-fixed-footer to the "modal" div*/}
    //     <div className="modal-content">
    //       <h4>Modal Header</h4>
    //       <p>A bunch of text</p>
    //     </div>
    //     <div className="modal-footer">
    //       <a className="modal-close waves-effect waves-red btn-flat">
    //         Disagree
    //       </a>
    //       <a className="modal-close waves-effect waves-green btn-flat">
    //         Agree
    //       </a>
    //     </div>
    //   </div>
    // </div>
  }
}

export default Modal;
