import React from "react";
import { withRouter } from "react-router-dom";

class Search extends React.Component {
  handleClick = () => {
    this.props.handleSearch(document.getElementById("search"));
    this.props.history.push(`/q/${document.getElementById("search").value}`);
  };
  render() {
    return (
      <div className="col s12">
        <div className="row">
          <div className="col s4 offset-s4 marginTopFour">
            <nav className="teal">
              <div className="nav-wrapper">
                <div className="input-field">
                  <input
                    onKeyPress={event =>
                      event.key === "Enter" ? this.handleClick() : null
                    }
                    id="search"
                    type="search"
                    autoComplete="off"
                    required
                    placeholder="Search a Book"
                  />
                  <i
                    className="material-icons"
                    id="sear"
                    onClick={() => this.handleClick()}
                  >
                    search
                  </i>
                </div>
              </div>
            </nav>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(Search);
