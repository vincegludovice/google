import React from "react";
import { Route, BrowserRouter } from "react-router-dom";
import gif from "./images/tenor.gif";
import Query from "./Query";

export default class Result extends React.Component {
  render() {
    return (
      <article className="container">
        <div className="row">
          <div className="preloader-background pre2">
            <div className="load load2">
              <hr />
              <hr />
              <hr />
              <hr />
            </div>
          </div>
          <div id="printHere">
            {this.props.term ? null : (
              <div className="col s12">
                <div className="card">
                  <div className="card-image">
                    <img src={gif} alt="" />
                    <span className="card-title white-text center-align">
                      The Cat is waiting for you to type something in the search
                      bar
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="row">
          <div className="col s6 offset-s3">
            <ul className="pagination" id="pagination"></ul>
          </div>
        </div>
      </article>
    );
  }
}
