import React from "react";

export default class Preloader extends React.Component {
  render() {
    return (
      <div className="preloader-background">
        <div className="load">
          <hr />
          <hr />
          <hr />
          <hr />
        </div>
      </div>
    );
  }
}
