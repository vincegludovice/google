import React from "react";
import { Route, BrowserRouter, Switch } from "react-router-dom";
import "./components/css/materialize/css/materialize.min.css";
import "./components/css/materialize/css/materialize.min.css";
import "./components/css/sweetalert2.min.css";
import "./App.css";
import Nav from "./components/Nav";
import Search from "./components/Search";
import Result from "./components/Result";
import ReadList from "./components/ReadList";
import Modal from "./components/Modal";
import Preloader from "./components/Preloader";
import NotFound from "./components/NotFound";
import Query from "./components/Query";
import Pagination from "./components/Pagination";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      term: "",
      isLoading: true,
      view: { showModal: false }
    };
  }
  componentDidMount() {
    this.timerHandle = setTimeout(
      () => this.setState({ isLoading: false }),
      0 //2000
    );
  }
  componentWillUnmount() {
    if (this.timerHandle) {
      clearTimeout(this.timerHandle);
      this.timerHandle = 0;
    }
  }
  handleSearch = e => {
    this.setState({
      term: e.value
    });
  };
  handleHideModal = () => {
    this.setState({ view: { showModal: false } });
  };
  handleShowModal = () => {
    this.setState({ view: { showModal: true } });
  };
  isbns = isbn => {
    this.setState({ isbn: isbn });
  };
  render() {
    if (this.state.isLoading) return <Preloader />;
    else {
      return (
        <BrowserRouter>
          <Switch>
            <Route
              exact
              path="/"
              render={() => (
                <div>
                  <Nav />
                  <Search
                    handleSearch={this.handleSearch}
                    history={this.props.history}
                  />
                  <Result term={this.state.term} />
                </div>
              )}
            />
            <Route
              path="/q/:term"
              render={props => (
                <div>
                  <Nav />
                  <Search
                    handleSearch={this.handleSearch}
                    history={this.props.history}
                  />
                  <article className="container">
                    <div className="row">
                      <div id="printHere">
                        <Query {...props} isbns={this.isbns} />
                      </div>
                      <Pagination {...props} />
                    </div>
                  </article>
                  <Modal clk={this.handleShowModal} isbn={this.state.isbn} />
                </div>
              )}
            />
            <Route
              path="/readList"
              render={() => (
                <div>
                  <Nav />
                  <ReadList />
                </div>
              )}
            />
            <Route component={NotFound} />
          </Switch>
          {/* <Nav />
          <Search />
          <Result />
          <ReadList />
          <Modal /> */}
        </BrowserRouter>
      );
    }
  }
}
